import java.util.Scanner;


public class Lecture {
    public static void main (String[] args){
        Scanner scanner = new Scanner(System.in);

    }
}
