import java.io.*;
import java.time.Duration;
import java.time.Instant;
import java.util.ArrayList;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class AutoAnalyzer {
    private static FileOutputStream outputStream;
    private static String lineSeparator = System.getProperty("line.separator");

    public static void main (String[] args) throws FileNotFoundException {
        Scanner input = new Scanner (System.in);
        System.out.print("ENTER DIRECTORY PATH: ");
        String directoryPath = input.nextLine();
        System.out.print("ENTER YOUR FILE NAME: ");
        String fileName = input.nextLine();
        File inputLog = new File(directoryPath + "\\" + fileName);
        Scanner scanner;


        Pattern fwVersionFinder = Pattern.compile("(Software revision\\s+: \\S+)");
        Pattern portStatusIndication = Pattern.compile("(?<faultIndication>Detect Stat: Other Fault)+");
        Pattern otherFaultFinder = Pattern.compile("(W \\d...*)+");
        Pattern upTimePattern = Pattern.compile("(Up Time\\s+: \\d* \\w*)");
        Pattern productNumberPattern = Pattern.compile("((?<productNumber>J\\S+) Configuration Editor)");
        String productNumberString = "";


        ArrayList<String> warnings = new ArrayList<>();
        ArrayList<String> systemInfo = new ArrayList<>();
        ArrayList<String> criticalErrors = new ArrayList<>();

        System.out.print("ENTER YOUR SAVE FILE NAME: ");
        String saveName = input.nextLine();
        outputStream = new FileOutputStream(directoryPath + "\\" + saveName);


        Instant start = Instant.now();
        try {
            scanner = new Scanner(inputLog);


            while (scanner.hasNextLine()){
                String line = scanner.nextLine();
                Matcher fwVersion = fwVersionFinder.matcher(line);
                Matcher portStatus = portStatusIndication.matcher(line);
                Matcher otherFault = otherFaultFinder.matcher(line);
                Matcher upTimeFinder = upTimePattern.matcher(line);
                Matcher productNumberFinder = productNumberPattern.matcher(line);


                if (fwVersion.find()) {
                    systemInfo.add(fwVersion.group());
                }
                if (productNumberFinder.find()){
                    productNumberString = productNumberFinder.group("productNumber");
                }
                if (upTimeFinder.find()){
                    systemInfo.add(upTimeFinder.group());
                }

                if (portStatus.find()){
                    criticalErrors.add(portStatus.group());
                }

                if (otherFault.find()){
                    if (otherFault.group().contains("failure") ||
                        otherFault.group().contains("Faulted") ||
                        otherFault.group().contains("Failures")||
                        otherFault.group().contains("selftest failure")){
                        criticalErrors.add(otherFault.group());
                    } else {
                        warnings.add(otherFault.group());
                    }
                }
            }

        } catch (IOException e) {
            e.printStackTrace();
        }

        String format = "System Info: ";
        try {
            outputStream.write(format.getBytes());
            outputStream.write(lineSeparator.getBytes());
            printArrayList(systemInfo);
            String preFixProductNumber = "Product Number: " + productNumberString;
            outputStream.write(preFixProductNumber.getBytes());
            outputStream.write(lineSeparator.getBytes());
        } catch (IOException e) {
            e.printStackTrace();
        }

        String criticalErrorsFound = "Critical Errors: ";

        try {
            outputStream.write(lineSeparator.getBytes());
            if (criticalErrors.isEmpty()){
                criticalErrorsFound = "No Critical Errors Found!";
            }
            outputStream.write(criticalErrorsFound.getBytes());
            outputStream.write(lineSeparator.getBytes());
          printArrayList(criticalErrors);
        } catch (IOException e) {
            e.printStackTrace();
        }


        String errorsFound = "Warnings Found: ";
        try {
            outputStream.write(lineSeparator.getBytes());
            if (warnings.isEmpty()){
                errorsFound = "No Warnings Found!";
            }
            outputStream.write(errorsFound.getBytes());
            outputStream.write(lineSeparator.getBytes());
        } catch (IOException e) {
            e.printStackTrace();
        }

     printArrayList(warnings);

        Instant end = Instant.now();

        System.out.println(lineSeparator + "ANALYSIS DONE! TIME TAKEN: " + Duration.between(start,end).toMillis() + " MILLISECONDS");

        System.out.println(String.format(lineSeparator +"Total Critical Errors Found: %d", criticalErrors.size()));
        System.out.println(String.format("Total Warnings Found: %d", warnings.size()));

        if (!criticalErrors.isEmpty()){
            System.out.println(lineSeparator + "Critical Errors found! Consider replacement for " + productNumberString);
        }


    }





    private static void printArrayList(ArrayList<String> arrayList) {


        arrayList.stream().forEach(e ->{
            try {
                outputStream.write(e.getBytes());
                outputStream.write(lineSeparator.getBytes());
            } catch (IOException e1) {
                e1.printStackTrace();
            }

        });

    }
}
