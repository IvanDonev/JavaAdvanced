package E02_CompanyRoster;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int n = Integer.parseInt(scanner.nextLine());

        Map<String, Department> departmentMap = new LinkedHashMap<>();

        while (n-- > 0){
            String[] currentEmployee = scanner.nextLine().split("\\s+");

            String name = currentEmployee[0];
            double salary = Double.parseDouble(currentEmployee[1]);
            String position = currentEmployee[2];

            Employee employee = new Employee(name, salary, position);

            String department = currentEmployee[3];


            if (currentEmployee.length >= 5){
                employee.setEmail(currentEmployee[4]);
            }

            if (currentEmployee.length == 6){
                employee.setAge(Integer.parseInt(currentEmployee[5]));
            }

            departmentMap.putIfAbsent(department, new Department(department));
            departmentMap.get(department).addEmployee(employee);

        }

        departmentMap.values().stream().sorted().limit(1).forEach(System.out::println);

        }
    }

