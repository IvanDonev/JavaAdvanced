package E02_CompanyRoster;

import java.util.ArrayList;
import java.util.List;

public class Department implements Comparable<Department> {
    private List<Employee> employeeList;
    private String name;
    private double averageSalary;

    public Department(String name) {
        this.name = name;
        this.employeeList = new ArrayList<>();
    }

    public void addEmployee(Employee employee){
        this.employeeList.add(employee);
        averageSalary += employee.getSalary();
        averageSalary /= employeeList.size();
    }

    public double getAverageSalary (){
        return this.averageSalary;
    }


    @Override
    public int compareTo(Department otherDepartment) {
        return Double.compare(otherDepartment.averageSalary, this.averageSalary);
    }

    @Override
    public String toString() {
       StringBuilder result = new StringBuilder();
       result.append(String.format("Highest Average Salary: %s%n", this.name));

       employeeList.stream().sorted().forEach(e -> {
           result.append(e);
           result.append(System.lineSeparator());
       });
        return result.toString();
    }
}
