package E06_PokemonTrainer;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Scanner;

public class Main {
    public static <element> void main (String[] args){
        Scanner scanner = new Scanner(System.in);

        Map<String, Trainer> trainerMap = new LinkedHashMap<>();

        String input = scanner.nextLine();

        while (!input.equalsIgnoreCase("Tournament")){
            String[] splitInput = input.split("\\s+");

            String trainerName = splitInput[0];
            String pokemonName = splitInput[1];
            String pokemonElement = splitInput[2];
            int pokemonHealth = Integer.parseInt(splitInput[3]);

            Pokemon currentPokemon = new Pokemon(pokemonName, pokemonElement, pokemonHealth);

            trainerMap.putIfAbsent(trainerName, new Trainer(trainerName));
            trainerMap.get(trainerName).pokemonList.add(currentPokemon);

            input = scanner.nextLine();
        }


        input = scanner.nextLine();

        while (!input.equalsIgnoreCase("End")){


            final String element = input;
            trainerMap.entrySet().forEach(e -> {
                e.getValue().checkElementsOfPokemons(element);
                e.getValue().checkIfPokemonsAreDead();
            });



            input = scanner.nextLine();
        }




        trainerMap.values().stream().sorted().forEach(System.out::println);


    }
}
