package E06_PokemonTrainer;

import java.util.ArrayList;
import java.util.List;

public class Trainer implements Comparable<Trainer>{
    private String name;
    private int badges = 0;
    List<Pokemon> pokemonList;

    public int getBadges() {
        return badges;
    }

    public int getPokemonCount(){
        return this.pokemonList.size();
    }

    public Trainer(String name) {
        this.name = name;
        this.pokemonList = new ArrayList<>();
    }

    public void checkIfPokemonsAreDead(){
        for (int i = 0; i < this.pokemonList.size(); i++) {
            if (this.pokemonList.get(i).isDead()){
                this.pokemonList.remove(i);
                i = 0;
            }
        }
    }

    public void checkElementsOfPokemons(String element){
        for (int i = 0; i < this.pokemonList.size(); i++) {
            if (this.pokemonList.get(i).getElement().equalsIgnoreCase(element)){
                this.badges += 1;
            } else {
                this.pokemonList.get(i).takeDamage();
            }
        }
    }

    @Override
    public int compareTo(Trainer otherTrainer) {
        return Integer.compare(otherTrainer.badges, this.badges);
    }

    @Override
    public String toString() {
        return String.format("%s %d %d", this.name, this.badges, getPokemonCount());
    }
}
