import java.util.LinkedHashMap;
import java.util.Map;

public class E02 {
    public static void main(String[] args) {
        Map<String, Integer> names = new LinkedHashMap<>();

       names.putIfAbsent()
    }
}
