import java.util.ArrayDeque;
import java.util.Arrays;
import java.util.Scanner;
import java.util.regex.Pattern;


public class E01 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        String[] message = scanner.nextLine().split("");
        ArrayDeque<String> stack = new ArrayDeque<>();

        stack.addAll(Arrays.asList(message));
        StringBuilder str = new StringBuilder();
        int index = 1;

      while (stack.size() > 0){
          if (stack.size() != 1){
              String currString = stack.poll();

              assert stack.peek() != null;
              if (stack.peek().equals(currString)){
                  index++;
              } else {
                  str.append(currString);
                  str.append(index);
                  index = 1;
              }
          } else {
              str.append(stack.poll());
              str.append(index);
          }
      }


      StringBuilder result = new StringBuilder();
        for (int i = 0; i <str.length(); i++) {
            if (str.charAt(i) != '1'){
                result.append(str.charAt(i));
            }

        }


        System.out.println(result);


    }

}
