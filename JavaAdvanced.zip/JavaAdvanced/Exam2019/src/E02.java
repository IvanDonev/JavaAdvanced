import java.util.Scanner;

public class E02 {
    public static int playerRow;
    public static int playerCol;

    public static int firstBlackHoleRow = -1;
    public static int firstBlackHoleCol = -1;

    public static int secondBlackHoleRow;
    public static int secondBlackHoleCol;





    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        int n = Integer.parseInt(scanner.nextLine());

        String[][] matrix = new String[n][];
        initializeMatrix(matrix, scanner);

        // Each turn, you will be given commands for the player’s movement. Move commands will be: "up", "down", "left", "right". If he moves to a star, he collects energy equal to the digit there and the star disappears. If he moves to a black hole, he appears on the position of the other black hole and then both black holes disappear. If a player goes out of the galaxy, he goes into the void, disappears from the galaxy and is lost forever. He needs at least 50 star power to build the Space Station.

        int starPower = 0;
        boolean intoTheVoid = false;
        boolean stationBuild = false;

        while(!intoTheVoid){

            if (stationBuild){
                break;
            }

            String movement = scanner.nextLine();
            boolean canMove = true;


            matrix[playerRow][playerCol] = "-";
            switch (movement){
                case "up":
                    canMove = checkMovement(playerRow - 1, playerCol, matrix);
                   playerRow--;
                    break;
                case "down":
                    canMove = checkMovement(playerRow + 1, playerCol, matrix);
                    playerRow++;
                    break;
                case "left":
                    canMove = checkMovement(playerRow, playerCol - 1, matrix);
                    playerCol--;
                    break;
                case "right":
                    canMove = checkMovement(playerRow, playerCol + 1, matrix);
                    playerCol++;
                    break;
            }

            if (canMove){
                if (matrix[playerRow][playerCol].equals("O")){
                   if (playerRow == firstBlackHoleRow && playerCol == firstBlackHoleCol){
                       matrix[playerRow][playerCol] = "-";
                       matrix[secondBlackHoleRow][secondBlackHoleCol] = "S";
                       playerRow = secondBlackHoleRow;
                       playerCol = secondBlackHoleCol;
                   } else if (playerRow == secondBlackHoleRow && playerCol == secondBlackHoleCol){
                       matrix[playerRow][playerCol] = "-";
                       matrix[firstBlackHoleRow][firstBlackHoleCol] = "S";
                       playerRow = firstBlackHoleRow;
                       playerCol = firstBlackHoleCol;
                   }
                } else if (Character.isDigit(matrix[playerRow][playerCol].charAt(0))){
                    int powerFromStar = Integer.parseInt(matrix[playerRow][playerCol]);
                    starPower += powerFromStar;
                    matrix[playerRow][playerCol] = "S";
                } else {
                    matrix[playerRow][playerCol] = "S";
                }
            } else {
                intoTheVoid = true;
            }

            if (starPower >= 50){
                stationBuild = true;
            }

        }


        if (intoTheVoid){
            System.out.println("Bad news, the spaceship went to the void.");
        } else if (stationBuild) {
            System.out.println("Good news! Stephen succeeded in collecting enough star power!");
        }

        System.out.println("Star power collected: " + starPower);

        for (int i = 0; i < matrix.length; i++) {
            for (int j = 0; j < matrix[i].length; j++) {
                System.out.print(matrix[i][j]);
            }
            System.out.println();
        }









    }

    private static boolean checkMovement(int newRow, int newCol, String[][] matrix) {
        return newRow >= 0 && newRow < matrix.length && newCol >= 0 && newCol < matrix[newRow].length;
    }

    private static void initializeMatrix(String[][] matrix, Scanner scanner) {
        boolean hasBlackHole = false;


        for (int i = 0; i < matrix.length; i++) {
            String input = scanner.nextLine();

            if (input.contains("S")){
                playerRow = i;
                playerCol = input.indexOf("S");
            }

            if (input.contains("O") && firstBlackHoleRow == -1){
                hasBlackHole = true;
                firstBlackHoleRow = i;
                firstBlackHoleCol = input.indexOf("O");
            }

            if (input.contains("O") && hasBlackHole){
                secondBlackHoleRow = i;
                secondBlackHoleCol = input.indexOf("O");
            }

            matrix[i] = input.split("");
        }

    }
}
