
import java.util.ArrayDeque;
import java.util.Arrays;
import java.util.Scanner;

public class E01 {
    public static void main (String[] args){
        Scanner scanner = new Scanner(System.in);

        ArrayDeque<Integer> liquids = new ArrayDeque<>();
        ArrayDeque<Integer> physicalMaterial = new ArrayDeque<>();

        Arrays.stream(scanner.nextLine().split(" "))
                .mapToInt(Integer::parseInt)
                .forEach(liquids::offer);

        Arrays.stream(scanner.nextLine().split(" "))
                .mapToInt(Integer::parseInt)
                .forEach(physicalMaterial::push);


        int aliminium = 0;
        int carbonFiber = 0;
        int glass = 0;
        int lithium = 0;


        while (!physicalMaterial.isEmpty() && !liquids.isEmpty()){
            int liquid = liquids.poll();
            int material = physicalMaterial.pop();

            int sumOfMaterials = liquid + material;
            boolean hasForged = false;

            switch (sumOfMaterials){
                case 25:
                    glass++;
                    hasForged = true;
                    break;
                case 50:
                    aliminium++;
                    hasForged = true;
                    break;
                case 75:
                    lithium++;
                    hasForged = true;
                    break;
                case 100:
                    carbonFiber++;
                    hasForged = true;
                    break;
            }


            if (!hasForged){
                material += 3;
                physicalMaterial.push(material);
            }


        }


        boolean hasMaterial = false;
        if (aliminium > 0 && carbonFiber > 0 && glass > 0 && lithium > 0){
            hasMaterial = true;
        }


        if (hasMaterial){
            System.out.println("Wohoo! You succeeded in building the spaceship!");
        } else {
            System.out.println("Ugh, what a pity! You didn't have enough materials to build the spaceship.");
        }

        if (liquids.isEmpty()){
            System.out.println("Liquids left: none");
        } else {
            System.out.print("Liquids left: ");
            while (!liquids.isEmpty()){
                if (liquids.size() > 1){
                    System.out.print(liquids.poll() + ", ");
                } else {
                    System.out.println(liquids.poll());
                }
            }
        }

        if (physicalMaterial.isEmpty()){
            System.out.println("Physical items left: none");
        } else {
            System.out.print("Physical items left: ");

            while (!physicalMaterial.isEmpty()){
                if (physicalMaterial.size() > 1){
                    System.out.print(physicalMaterial.pop() + ", ");
                } else {
                    System.out.println(physicalMaterial.pop());
                }
            }

        }

        // Aluminium: 1
        //Carbon fiber: 0
        //Glass: 1
        //Lithium: 0

        System.out.println("Aluminium: " + aliminium);
        System.out.println("Carbon fiber: " + carbonFiber);
        System.out.println("Glass: " + glass);
        System.out.println("Lithium: " + lithium);

    }
}
