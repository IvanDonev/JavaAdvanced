package spaceStationRecruitment;

public class Main {
    public static void main(String[] args) {
// Initialize the repository
        SpaceStation spaceStation = new SpaceStation("Apolo", 10);
        Astronaut secondAstronaut = new Astronaut("Mark", 340, "UK");

// Initialize entity
        Astronaut astronaut = new Astronaut("Stephen", 40, "Bulgaria");

        System.out.println(astronaut.getName());
        System.out.println(astronaut.getAge());




        System.out.println(spaceStation.getCapacity());
        System.out.println(spaceStation.getName());
        System.out.println(spaceStation.getCount());

// Print Astronaut
        System.out.println(secondAstronaut); // Astronaut: Stephen, 40 (Bulgaria)

// Add Astronaut
        spaceStation.add(astronaut);

// Remove Astronaut
        spaceStation.remove("Astronaut name"); // false


// Add Astronaut
        spaceStation.add(secondAstronaut);

        Astronaut oldestAstronaut = spaceStation.getOldestAstronaut();
// Astronaut with name Stephen

        Astronaut astronautStephen = spaceStation.getAstronaut("Mark");
// Astronaut with name Stephen



// Print Astronauts
        System.out.println(spaceStation.getCapacity());
        System.out.println(oldestAstronaut); // Astronaut: Stephen, 40 (Bulgaria)
        System.out.println(astronautStephen); // Astronaut: Stephen, 40 (Bulgaria)

        System.out.println(spaceStation.getCount()); // 2
        System.out.println(spaceStation.report());

// Astronauts working at Space Station Apolo:
// Astronaut: Stephen, 40 (Bulgaria)
// Astronaut: Mark, 34 (UK)

    }
}
