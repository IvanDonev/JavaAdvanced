package spaceStationRecruitment;

import java.util.ArrayList;
import java.util.List;

public class SpaceStation {
    private String name;
    private int capacity;
    private List<Astronaut> data;


    public SpaceStation(String name, int capacity) {
        this.name = name;
        this.capacity = capacity;
        this.data = new ArrayList<>(capacity);
    }

    public String getName() {
        return name;
    }

    public int getCapacity() {
        return capacity;
    }

    public int getCount() {
        return this.data.size();
    }

    public void add(Astronaut astronaut) {
        boolean canBeAssigned = true;

        for (int i = 0; i < data.size(); i++) {
            if (data.get(i).getName().equals(astronaut.getName())){
                canBeAssigned = false;
            }
        }

        if (this.data.size() < this.capacity && canBeAssigned){
            data.add(astronaut);
        }
    }

    public boolean remove(String name) {
        boolean removed = false;
        for (int i = 0; i < data.size(); i++) {
            if (data.get(i).getName().equals(name)){
                Astronaut astronaut = data.get(i);
                data.remove(astronaut);
                removed = true;
            }
        }
        return removed;
    }

    public Astronaut getOldestAstronaut() {
        int oldestAge = 0;
        Astronaut oldestAstronaut = null;


        for (Astronaut astronaut : data) {
            if (astronaut.getAge() > oldestAge) {
                oldestAge = astronaut.getAge();
                oldestAstronaut = astronaut;
            }
        }

        return oldestAstronaut;
    }

    public Astronaut getAstronaut(String name) {
        Astronaut wantedAstronaut = null;

        for (Astronaut astronaut : data) {
            if (astronaut.getName().equals(name)) {
                wantedAstronaut = astronaut;
            }
        }

        return wantedAstronaut;
    }


    public String report(){
        StringBuilder result = new StringBuilder();
        result.append("Astronauts working at Space Station " + this.name + ": " + System.lineSeparator());
        data.forEach(e -> result.append(e + System.lineSeparator()));
        return result.toString();
    }

}
