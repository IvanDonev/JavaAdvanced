import java.util.Scanner;

public class E02_TronRacer {
    public static int[] firstPlayer = new int[2];
    public static int[] secondPlayer = new int[2];
    public static boolean endGame = false;

    public static void main (String[] args){
        Scanner scanner = new Scanner(System.in);

        int n = Integer.parseInt(scanner.nextLine());
        String[][] matrix = new String[n][];


        for (int i = 0; i < n ; i++) {
            matrix[i] = scanner.nextLine().split("");
        }

        findPosition(matrix);
        System.out.println();


        while (!endGame){
            String[] input = scanner.nextLine().split(" ");
            String playerOneCommand = input[0];
            String playerTwoCommand = input[1];

            moveFirstPlayer(playerOneCommand, matrix);
            moveSecondPlayer(playerTwoCommand, matrix);

        }

        for (int i = 0; i < matrix.length ; i++) {
            for (int j = 0; j < matrix.length; j++) {
                System.out.print(matrix[i][j]);
            }
            System.out.println();
        }




    }

    private static void moveSecondPlayer(String playerTwoCommand, String[][] matrix) {
        switch (playerTwoCommand) {
            case "up":
                secondPlayer[0] = (secondPlayer[0] - 1) % matrix.length;
                break;
            case "down":
                secondPlayer[0] = (secondPlayer[0] + 1) % matrix.length;
                break;
            case "left":
                secondPlayer[1] = (matrix.length + (secondPlayer[1] - 1)) % matrix.length;
                break;
            case "right":
                secondPlayer[1] = (secondPlayer[1] + 1) % matrix.length;
                break;

        }

        if (matrix[secondPlayer[0]][secondPlayer[1]].equals("*") || matrix[secondPlayer[0]][secondPlayer[1]].equals("s")){
            matrix[secondPlayer[0]][secondPlayer[1]] = "s";
        } else if (matrix[secondPlayer[0]][secondPlayer[1]].equals("f")){
            matrix[secondPlayer[0]][secondPlayer[1]] = "x";
            endGame = true;
        }

    }

    private static void moveFirstPlayer(String playerOneCommand, String[][] matrix) {

        switch (playerOneCommand) {
            case "up":
                firstPlayer[0] = (firstPlayer[0] - 1) % matrix.length;
                break;
            case "down":
                firstPlayer[0] = (firstPlayer[0] + 1) % matrix.length;
                break;
            case "left":
                firstPlayer[1] = (matrix.length + (firstPlayer[1] - 1)) % matrix.length;
                break;
            case "right":
                firstPlayer[1] = (firstPlayer[1] + 1) % matrix.length;
                break;

        }

        if (matrix[firstPlayer[0]][firstPlayer[1]].equals("*") || matrix[firstPlayer[0]][firstPlayer[1]].equals("f")){
            matrix[firstPlayer[0]][firstPlayer[1]] = "f";
        } else if (matrix[firstPlayer[0]][firstPlayer[1]].equals("s")){
            matrix[firstPlayer[0]][firstPlayer[1]] = "x";
            endGame = true;
        }


    }

    private static void findPosition(String[][] matrix) {
        for (int i = 0; i < matrix.length; i++) {
            for (int j = 0; j < matrix.length; j++) {
                if (matrix[i][j].equals("f")){
                    firstPlayer[0] = i;
                    firstPlayer[1] = j;
                } else if (matrix[i][j].equals("s")){
                    secondPlayer[0] = i;
                    secondPlayer[1] = j;
                }
            }
        }





    }
}
