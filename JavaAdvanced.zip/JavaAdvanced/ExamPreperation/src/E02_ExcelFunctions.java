
import java.util.Arrays;
import java.util.Scanner;

public class E02_ExcelFunctions {
    static int index = 0;
    public static void main (String[] args){
        Scanner scanner = new Scanner(System.in);

        int n = Integer.parseInt(scanner.nextLine());

        String[][] matrix = new String[n][];

        for (int i = 0; i < n; i++) {
            String[] currRow = scanner.nextLine().split(", ");
            matrix[i] = currRow;
        }

       String[] commandInput = scanner.nextLine().split(" ");
        String commandType = commandInput[0];

        switch (commandType){
            case "hide":
                String columnToHide = commandInput[1];
                hideColumn(matrix, columnToHide);
                break;
            case "sort":
                String columnToOrder = commandInput[1];
                orderColumn(matrix, columnToOrder);
                break;
            case "filter":
                String columnToFilterBy = commandInput[1];
                String filter = commandInput[2];
                filterMatrixBy(matrix, columnToFilterBy, filter);
                return;
        }




        Arrays.stream(matrix).forEach(e -> {
            Arrays.stream(e).forEach(p -> {
                ++index;
                if (index < matrix.length - 1 && !p.equals("DoNotPrint")){
                    System.out.print(p + " | ");
                } else if (!p.equals("DoNotPrint")){
                    System.out.print(p);
                }

            });
            index = 0;
            System.out.println();

        });





    }

    private static void filterMatrixBy(String[][] matrix, String columnToFilterBy, String filter) {
        int columnIndex = 0;

        for (int i = 0; i < matrix.length - 1; i++) {
            if (matrix[0][i].equalsIgnoreCase(columnToFilterBy)){
                columnIndex = i;
            }
        }

        printFirstLine(matrix);
        for (int i = 1; i < matrix.length ; i++) {
            if (matrix[columnIndex][i].equals(filter)){
                System.out.println(String.join(" | ", matrix[i]));
            }
        }



    }

    private static void printFirstLine(String[][] matrix) {
        for (int i = 0; i < matrix.length; i++) {
            if (i < matrix.length - 1){
                System.out.print(matrix[0][i] + " | ");
            }else {
                System.out.print(matrix[0][i]);
            }
        }
        System.out.println();
    }

    private static void orderColumn(String[][] matrix, String columnToOrder) {
        int columnIndex = 0;

        for (int i = 0; i < matrix.length - 1; i++) {
            if (matrix[0][i].equalsIgnoreCase(columnToOrder)){
                columnIndex = i;
            }
        }


        for (int j = 0; j < matrix.length; j++) {

        for (int i = 1; i < matrix.length - 1 - j; i++) {
            if (matrix[i][columnIndex].compareTo(matrix[i + 1][columnIndex]) > 0){
                String[] tempRow = matrix[i];
                matrix[i] = matrix[i + 1];
                matrix[i + 1] = tempRow;

            }

        }
        }


    }

    private static void hideColumn(String[][] matrix, String columnToHide) {
        int columnIndex = 0;

        for (int i = 0; i < matrix.length - 1; i++) {
            if (matrix[0][i].equalsIgnoreCase(columnToHide)){
                columnIndex = i;
            }
        }

        for (int i = columnIndex; i <= columnIndex ; i++) {
            for (int j = 0; j < matrix.length; j++) {
                matrix[j][i] = "DoNotPrint";
            }
        }



    }
}
