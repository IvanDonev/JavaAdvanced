import java.util.*;

public class E01_Hospital {
    public static void main (String[] args){
        Scanner scanner = new Scanner(System.in);
        Map<String, Department> departmentMap = new LinkedHashMap<>();

        String input = scanner.nextLine();

        while (!input.equals("Output")){
            String[] splitInput = input.split("\\s+");

            String department = splitInput[0];
            String doctorName = splitInput[1] + " " + splitInput[2];
            String patientName = splitInput[3];

            Department currentDepartment = new Department(department);
            Doctor currentDoctor = new Doctor(doctorName);
            Patient patient = new Patient(patientName);


            currentDoctor.patients.add(patient);
            currentDepartment.doctorList.add(currentDoctor);
            currentDepartment.assignPatient(patient);

            departmentMap.putIfAbsent(department, currentDepartment);


            input = scanner.nextLine();
        }

        System.out.println();





    }
}


 class Department {
   private String name;
    Map<Integer, List<Patient>> rooms;
    List<Doctor> doctorList;

    public Department (String name){
        this.name = name;
        this.doctorList = new ArrayList<>();
        this.rooms = new LinkedHashMap<>();
        for (int i = 1; i <= 20 ; i++) {
            this.rooms.putIfAbsent(i, new LinkedList<>());
        }
    }

    public void assignPatient(Patient patient){
        for (int i = 0; i < this.rooms.size(); i++) {
            if (rooms.values().size() < 3){
                rooms.get(i).add(patient);
                patient.assignPatient();
                return;
            }
        }

    }


 }

 class Doctor {
    String name;
    List<Patient> patients;

    public Doctor(String name){
        this.name = name;
        this.patients = new ArrayList<>();
    }

 }

 class Patient {
    String name;
    boolean canBeAssigned;

    public Patient(String name){
        this.name = name;
        canBeAssigned = true;
    }

    public void assignPatient (){
        this.canBeAssigned = false;
    }

 }
