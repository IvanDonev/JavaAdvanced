package Excersise;

import java.util.ArrayDeque;
import java.util.Scanner;

public class E02_BasicStackOperations {
    public static void main (String[] args){
        Scanner scanner = new Scanner(System.in);


        String[] commandInput = scanner.nextLine().split("\\s+");
        String[] numberInputs = scanner.nextLine().split("\\s+");

        ArrayDeque<Integer> stack = new ArrayDeque<>();

        int n = Integer.parseInt(commandInput[0]);
        int s = Integer.parseInt(commandInput[1]);
        int x = Integer.parseInt(commandInput[2]);

        for (int i = 0; i < n ; i++) {
            stack.push(Integer.parseInt(numberInputs[i]));
        }

        for (int i = 0; i < s ; i++) {
            stack.pop();
        }


        if (stack.isEmpty()){
            System.out.println(0);
        }

        if (stack.contains(x)){
            System.out.println("true");
        } else {
            stack.stream().sorted((e1, e2) -> {
              int sort = Integer.compare(e1, e2);

                return sort;
            })
            .limit(1)
            .forEach(System.out::println);
        }


    }

}
