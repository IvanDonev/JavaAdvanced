package Excersise;

import java.util.ArrayDeque;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Scanner;

public class E05_Robotics {
    public static void main (String[] args){
        Scanner scanner = new Scanner(System.in);


        String[] robotInput = scanner.nextLine().split(";");
        Map<String, Integer> robotAndProcessingTime = new LinkedHashMap<>();
        ArrayDeque<String> productQueue = new ArrayDeque<>();
        int[] workTime = new int[robotAndProcessingTime.size()];


        for (int i = 0; i < robotInput.length; i++) {
            String[] robotWithProcessingTime = robotInput[i].split("-");
            robotAndProcessingTime.putIfAbsent(robotWithProcessingTime[0], Integer.parseInt(robotWithProcessingTime[1]));
        }


        String[] timeInput = scanner.nextLine().split(":");
        int hours = Integer.parseInt(timeInput[0]);
        int minutes = Integer.parseInt(timeInput[1]);
        int seconds = Integer.parseInt(timeInput[2]);

        int timeToSeconds = (hours * 60 * 60) + (minutes * 60) + seconds;

        System.out.println(timeToSeconds);

        String command = scanner.nextLine();

        while(!command.equalsIgnoreCase("End")){
            productQueue.offer(command);
            command = scanner.nextLine();
        }

        System.out.println();





    }
}
