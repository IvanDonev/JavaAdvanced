package Excersise;

import java.util.ArrayDeque;
import java.util.Scanner;

public class E03_MaximumElement {

    public static void main (String[] args){
        Scanner scanner = new Scanner(System.in);

        int n = Integer.parseInt(scanner.nextLine());
        ArrayDeque<Integer> stack = new ArrayDeque<>();


        while(n-- > 0){
            String[] input = scanner.nextLine().split("\\s+");

            if (input[0].equalsIgnoreCase("1")){
                stack.push(Integer.parseInt(input[1]));
            } else if (input[0].equalsIgnoreCase("2")){
                stack.pop();
            } else {
                stack.stream().sorted((e1, e2) -> Integer.compare(e2, e1)).limit(1).forEach(System.out::println);
            }


        }






    }
}
