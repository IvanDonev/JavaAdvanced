package Excersise;

import java.util.ArrayDeque;
import java.util.Scanner;

public class E04_BasicQueueOperations {
    public static void main (String[] args){
        Scanner scanner = new Scanner(System.in);

        String[] inputCommands = scanner.nextLine().split("\\s+");
        String[] numbers = scanner.nextLine().split("\\s+");

        ArrayDeque<Integer> queue = new ArrayDeque<>();

        int n = Integer.parseInt(inputCommands[0]);
        int s = Integer.parseInt(inputCommands[1]);
        int x = Integer.parseInt(inputCommands[2]);

        for (int i = 0; i < n ; i++) {
            queue.add(Integer.parseInt(numbers[i]));
        }

        for (int i = 0; i < s; i++) {
            queue.poll();
        }

        if (queue.isEmpty()){
            System.out.println("0");
        }

        if (queue.contains(x)){
            System.out.println("true");
        } else {
            queue.stream().sorted((e1, e2) -> Integer.compare(e1, e2)
            ).limit(1).forEach(System.out::println);
        }

    }
}
